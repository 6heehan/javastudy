package com.example.demo.components;

import javax.mail.internet.MimeMessage;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
public class MailComponents {

	private final JavaMailSender javaMailSender;
	public void sendMailTest() {
		SimpleMailMessage msg = new SimpleMailMessage();
		msg.setTo("6heehan@gmail.com");
		msg.setSubject("안녕하세요, 제로베이스 입니다.");
		msg.setText("안녕하세요. 제로베이스 입니다. 반갑습니다.");
		javaMailSender.send(msg);
	}
	
	public boolean sendMail(String mail, String subject, String text) {
		
		boolean result = false;
		MimeMessagePreparator msg =new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				// TODO Auto-generated method stub
				MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
				messageHelper.setTo(mail);
				messageHelper.setSubject(subject);
				messageHelper.setText(text, true);
			}
		};
		try { 
			javaMailSender.send(msg);
			result = true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return result;
 		
	}
}
